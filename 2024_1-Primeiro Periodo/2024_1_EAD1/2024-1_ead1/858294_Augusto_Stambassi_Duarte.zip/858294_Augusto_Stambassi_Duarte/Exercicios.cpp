/*
Exercicios- v1.0 - 09 / 05 / 2024
Author: Augusto Stambassi Duarte
*/

// dependencias
#include <iostream> // std::cin, std::cout, std:endl
#include <limits> // std::numeric_limits
#include <string> // para cadeias de caracteres
#include "Array.cpp"
// ----------------------------------------------- definicoes globais
void pause ( std::string text ) {
	std::string dummy;
	std::cin.clear ( );
	std::cout << std::endl << text;
	std::cin.ignore( );
	std::getline(std::cin, dummy);
	std::cout << std::endl << std::endl;
} // end pause ( )
// ----------------------------------------------- classes / pacotes
using namespace std;


// Metodos

/**
  Method_01 - Acrescentar valor no final de um arranjo, usando apontadores
 */
void method_01 ( ) {
// definir dado
	int n;
	int x;

// identificar
	cout << "\nMethod_01 - v1.0\n" << endl;

cout << "N = ";
cin >> n; getchar();
Int_Array* arranjo = new Int_Array(n, 0);

// entrada de dados
	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();

// chamada de funcao

	for (int i = n; i < n * 2; i++) {
		cout << "PushBack [" << i << "]: ";
		cin >> x; getchar();
		arranjo->pushBack(x);
	}
	cout << endl << "Arranjo - Depois PushBack" << endl;
	arranjo->print();
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_01 ( )


/**
  Method_02 - Retirar um valor do final de um arranjo, usando apontadores
 */
void method_02 ( ) {
// definir dado
	int n;
	int x;
	
// identificar
	cout << "\nMethod_02 - v1.0\n" << endl;
	
	
// entrada de dados

	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);

	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();

// chamada de funcao

	for (int i = 0; i < 2; i++) {
		arranjo->popBack();
	}
	cout << endl << "Arranjo - Depois pop back" << endl;
	arranjo->print();

// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_02 ( )

/**
  Method_03 - Acrescentar valor no comeco do arranjo, por meio de apontadores
 */
void method_03 ( ) {
// definir dado
	int n;
	int x;


// identificar
	cout << "\nMethod_03 - v1.0\n" << endl;

// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();

// chamada de funcao

	for (int i = 0; i < 2; i++) {
		cout << "Push Front [" << i << "]: ";
		cin >> x; getchar();
		arranjo->pushFront(x);
	}
	cout << endl << "Arranjo - Depois push front" << endl;
	arranjo->print();

// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_1013 ( )

/**
  Method_04 - Retirar o valor do inicio, usando apontadores
 */
void method_04 ( ) {
// definir dado
	int n;
	int x;
	

// identificar
	cout << "\nMethod_04 - v1.0\n" << endl;

// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();

// chamada de funcao
	cout << "Quantos popFronts: ";
	cin >> x; getchar();
	for (int i = 0; i < x; i++) {
		arranjo->popFront();
	}
	cout << endl << "Arranjo - Depois pop front" << endl;
	arranjo->print();

// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_04 ( )

/**
  Method_05 - Colocar um novo valor no meio(aproximadamente)
 */
void method_05 ( ) {
// definir dado
	int n;
	int x;


// identificar
	cout << "\nMethod_05 - v1.0\n" << endl;

// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();

// chamada de funcao
	
	cout << "Qual valor para colocar no meio: ";
	cin >> x; getchar();
	arranjo->pushMid(x);
	cout << endl << "Arranjo - Depois push mid" << endl;
	arranjo->print();

// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_1015 ( )

/**
  Method_06 - Retirar o valor do meio(aproximadamente)
 */
void method_06 ( ) {
// definir dado
	int n;
	int x;

	
// identificar
	cout << "\nMethod_06 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	arranjo->read();
	cout << endl << "Arranjo - Original" << endl;
	arranjo->print();
	
// chamada de funcao

	arranjo->popMid();
	cout << endl << "Arranjo - Depois pop mid" << endl;
	arranjo->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_06 ( )

/**
  Method_1017 - comparacao de arranjos
 */
void method_07 ( ) {
// definir dado
	int n;
	int x;

// identificar
	cout << "\nMethod_07 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	Int_Array* arranjo2 = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	cout << endl << "Arranjo 2" << endl;
	arranjo2->read();

// chamada de funcao
	int resposta = arranjo->cmp(arranjo2);
	cout << endl << "Comparacao: " <<  resposta << endl;
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_1017 ( )

/**
  Method_08 - juntar dois arranjos
 */
void method_08 ( ) {
// definir dado
	int n;
	int x;
	
// identificar
	cout << "\nMethod_08 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	cout << "N = ";
	cin >> n;
	Int_Array* arranjo2 = new Int_Array(n, 0);
	cout << endl << "Arranjo 2" << endl;
	arranjo2->read();
	
// chamada de funcao
	arranjo->cat(arranjo2);
	cout << endl << "Arranjo 1 + Arranjo 2" << endl;
	arranjo->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_08 ( )


/**
  Method_09 - Metodo de procura
 */
void method_09 ( ) {
// definir dado
	int n;
	int x;
	
// identificar
	cout << "\nMethod_09 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	Int_Array* procura;
	
// chamada de funcao
	cout << "Qual valor dejesa procurar? ";
	cin >> n; getchar();
	procura = arranjo->seek(n);
	procura->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_09 ( )

/**
  Method_10 - Separar sequencia de valores em arranjo (slice)
 */
void method_10 ( ) {
// definir dado
	int n;
	int x;
	
// identificar
	cout << "\nMethod_10 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	Int_Array* a2;
	
// chamada de funcao
	cout << "Tamanho: ";
	cin >> n; getchar();
	cout << "Comeco: ";
	cin >> x; getchar();
	a2 = arranjo->sub(x,n);
	a2->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_10 ( )


/**
  Method_E1 - intercalar arranjos
 */
void method_E1 ( ) {
// definir dados
	int n;
	int x;
	
// identificar
	cout << "\nMethod_E1 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo2 = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 2" << endl;
	arranjo2->read();
	
	Int_Array* result;
	
// chamada de funcao
	result = arranjo->merge(arranjo2);
	result->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_E1 ( )


/**
  Method_E2 - Intercalar arranjos em ordem crescente
 */
void method_E2 ( ) {
// definir dados
	int n;
	int x;
	
// identificar
	cout << "\nMethod_E2 - v1.0\n" << endl;
	
// entrada de dados
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 1" << endl;
	arranjo->read();
	
	cout << "N = ";
	cin >> n; getchar();
	Int_Array* arranjo2 = new Int_Array(n, 0);
	
	cout << endl << "Arranjo 2" << endl;
	arranjo2->read();
	
	Int_Array* result;
	
// chamada de funcao
	result = arranjo->mergeUp(arranjo2);
	result->print();
	
// encerrar
	cout << "\nAperte <Enter> para continuar\n" << endl;
	getchar( );
} // end method_E2 ( )


// -------------------------- definicao do metodo principal

int main ( void ) {
	// definir dados/resultados
	int opcao = 0;

	// repetir ate' desejar parar
	do {
		// identificar
		cout << "\nExercicios - Program - v1.0\n" << endl;
		// mostrar opcoes
		cout << "\nOpcoes:";
		cout << "\n0 - parar";
		cout << "\n1 - metodo 1011   2 - metodo 1012";
		cout << "\n3 - metodo 1013   4 - metodo 1014";
		cout << "\n5 - metodo 1015   6 - metodo 1016";
		cout << "\n7 - metodo 1017   8 - metodo 1018";
		cout << "\n9 - metodo 1019   10 - metodo 1020";
		cout << "\n11 - metodo 10E1  12 - metodo 10E2";
		cout << endl << endl;       // para saltar linha

		// ler opcao
		cout << "Entrar com uma opcao: ";
		cin >> opcao;
		getchar();

		// escolher acao
		switch ( opcao ) {
			case  0:
				break;
			case  1:
				method_01 ( );
				break;
			case  2:
				method_02 ( );
				break;
			case  3:
				method_03 ( );
				break;
			case  4:
				method_04 ( );
				break;
			case  5:
				method_05 ( );
				break;
			case  6:
				method_06( );
				break;
			case  7:
				method_07 ( );
				break;
			case  8:
				method_08 ( );
				break;
			case  9:
				method_09 ( );
				break;
			case 10:
				method_10 ( );
				break;
			case 11:
				method_E1 ( );
				break;
			case 12:
				method_E2 ( );
				break;
			default:
				cout << "\nERRO: Opcao invalida\n" << endl;
				break;
		} // fim escolher
	} while ( opcao != 0 );

	// encerrar execucao
	cout << "\nAperte <Enter> para terminar\n" << endl;
	getchar( );

} // end main ( )


/*
----------------------------- documentacao complementar


----------------------------- notas / observacoes / comentarios


----------------------------- previsao de testes - 01
Method_01 - v1.0  OK

N = 3

0 : 1
1 : 2
2 : 3


Arranjo - Original

0 :         1
1 :         2
2 :         3

PushBack [3]: 10
PushBack [4]: 20
PushBack [5]: 30

Arranjo - Depois PushBack

0 :         1
1 :         2
2 :         3
3 :        10
4 :        20
5 :        30
----------------------------- previsao de testes - 02
Method_02 - v1.0

N=5

0 : 5
1 : 4
2 : 3
3 : 2
4 : 1


Arranjo - Original

0 :         5
1 :         4
2 :         3
3 :         2
4 :         1


Arranjo - Depois pop back

0 :         5
1 :         4
2 :         3
----------------------------- previsao de testes - 03
Method_03 - v1.0

N=5


0 : 1
1 : 2
2 : 3
3 : 4
4 : 5


Arranjo - Original

0 :         1
1 :         2
2 :         3
3 :         4
4 :         5

Push Front [0]: 10
Push Front [1]: 20

Arranjo - Depois push front

0 :        20
1 :        10
2 :         1
3 :         2
4 :         3
5 :         4
6 :         5
----------------------------- previsao de testes - 04
Method_04 - v1.0

N=5


0 : 1
1 : 2
2 : 3
3 : 4
4 : 5


Arranjo - Original

0 :         1
1 :         2
2 :         3
3 :         4
4 :         5

Quantos popFronts: 3

Arranjo - Depois pop front

0 :         4
1 :         5
----------------------------- previsao de testes - 05

Method_05 - v1.0

N = 4


0 : 10
1 : 20
2 : 30
3 : 40


Arranjo - Original

0 :        10
1 :        20
2 :        30
3 :        40

Qual valor para colocar no meio: 5

Arranjo - Depois push mid

0 :        10
1 :        20
2 :         5
3 :        30
4 :        40
----------------------------- previsao de testes - 06
Method_06 - v1.0

N = 5

0 : 1
1 : 2
2 : 3
3 : 4
4 : 5


Arranjo - Original

0 :         1
1 :         2
2 :         3
3 :         4
4 :         5


Arranjo - Depois pop mid

0 :         1
1 :         2
2 :         4
3 :         5

----------------------------- previsao de testes - 07
Method_07 - v1.0

N = 5

Arranjo 1

0 : 1
1 : 2
2 : 3
3 : 4
4 : 5


Arranjo 2

0 : 5
1 : 4
2 : 3
3 : 2
4 : 1


Comparacao: -4
----------------------------- previsao de testes - 08
Method_08 - v1.0

N = 3

Arranjo 1

0 : 10
1 : 20
2 : 30

N = 3

Arranjo 2

0 : 1
1 : 2
2 : 3


Arranjo 1 + Arranjo 2

0 :        10
1 :        20
2 :        30
3 :         1
4 :         2
5 :         3
----------------------------- previsao de testes - 09
Method_09 - v1.0

N = 5

Arranjo 1

0 : 1
1 : 2
2 : 3
3 : 4
4 : 5

Qual valor dejesa procurar? 3

0 :         3
----------------------------- previsao de testes - 10
Method_10 - v1.0

N = 10

Arranjo 1

0 : 1
1 : 2
2 : 3
3 : 4
4 : 5
5 : 6
6 : 7
7 : 8
8 : 9
9 : 10

Tamanho: 3
Comeco: 5

0 :         6
1 :         7
2 :         8

----------------------------- previsao de testes - E1
Method_E1 - v1.0

N = 3

Arranjo 1

0 : 2
1 : 3
2 : 1

N = 5

Arranjo 2

0 : 10
1 : 15
2 : 8
3 : 9
4 : 13


0 :         2
1 :        10
2 :         3
3 :        15
4 :         1
5 :         8
6 :         9
7 :        13
----------------------------- previsao de testes - E2
Method_E2 - v1.0

N = 3

Arranjo 1

0 : 2
1 : 3
2 : 1

N = 5

Arranjo 2

0 : 10
1 : 15
2 : 8
3 : 9
4 : 13


0 :         1
1 :         2
2 :         3


0 :         8
1 :         9
2 :        10
3 :        13
4 :        15


0 :         1
1 :         8
2 :         2
3 :         9
4 :         3
5 :        10
6 :        13
7 :        15

----------------------------- historico

Versao		Data		      Modificacao
0.1			09/05		      esboco + metodo1011
0.2			09/05		      metodo1012
0.3			09/05		      metodo1013
0.4			09/05		      metodo1014
0.5			09/05		      metodo1015
0.6			09/05		      metodo1016
0.7			09/05		      metodo1017
0.8			09/05		      metodo1018
0.9			09/05		      metodo1019
1.0			09/05		      metodo1020
1.E1		09/05		      metodo10E1
0.E2		09/05		      metodo10E2

---------------------------- testes

Versao		Teste
0.1			01. ( OK )	      identificacao de programa
0.2			01. ( OK )
0.3			01. ( OK )
0.4			01. ( OK )
0.5			01. ( OK )
0.6			01. ( OK )
0.7			01. ( OK )
0.8			01. ( XX )
0.8			02. ( OK )
0.9			01. ( OK )
1.0			01. ( OK )
1.E1		01. ( OK )
1.E2		01. ( OK )

*/
