/*
Array.hpp - v0.0. - 21 / 06 / 2024
Author: Augusto Stambassi Duarte
*/
// ----------------------------------------------- definicoes globais

// dependencias
#ifndef Array_H
#define Array_H
#include <iostream>
using std::cin ; // para entrada
using std::cout; // para saida
using std::endl; // para mudar de linha
#include <iomanip>
using std::setw; // para definir espacamento
#include <string>
using std::string; // para cadeia de caracteres
#include <fstream>
using std::ofstream; // para gravar arquivo
using std::ifstream ; // para ler arquivo



class Int_Array {
	private: // area reservada
		int length;
		int *data;
	public: // area aberta
		Int_Array ( int n, int inicial ) {
			// definir valores iniciais
			length = 0;
			data = nullptr;
			// reservar area
			if ( n > 0 ) {
				length = n;
				data = new int [ length ];
				if (data) {
					for (int i = 0; i < length; i++) {
						data[i] = inicial;
					}
				}
			}
		} // end constructor

		Int_Array ( ) { // construtor padrao
			// definir valores iniciais
			length = 0;
			// reservar area
			data = nullptr;
		} // end constructor

		// contrutor baseado em copia
		Int_Array ( int length, int other [ ] ) {
			if ( length <= 0 ) {
				cout << "\nERROR: Missing data.\n" << endl;
			} else {
				// criar copia
				this->length = length;
				// reservar area
				data = new int [ this->length ];
				// ler dados
				for ( int x = 0; x < this->length; x = x + 1 ) {
					data [ x ] = other [ x ];
				} // end for
			} // end if
		} // end constructor ( )

		Int_Array ( const Int_Array& other ) {
			if ( other.length <= 0 ) {
				cout << "\nERROR: Missing data.\n" << endl;
			} else {
				// criar copia
				length = other.length;
				// reservar area
				data = new int [ other.length ];
				// ler dados
				for ( int x = 0; x < length; x = x + 1 ) {
					data [ x ] = other.data [ x ];
				} // end for
			} // end if
		} // end constructor ( )

		void free ( ) {
			if ( data != nullptr ) {
				delete ( data );
				data = nullptr;
			} // end if
		} // end free ( )

		void set ( int position, int value ) {
			if ( 0 <= position && position < length ) {
				data [ position ] = value;
			} // end if
		} // end set ( )

		int get ( int position ) {
			int value = -1;
			if ( 0 <= position && position < length ) {
				value = data [ position ];
			} // end if
			return ( value );
		} // end get ( )

		void print ( ) {
			cout << endl;
			for ( int x = 0; x < length; x = x + 1 ) {
				cout << setw( 3 ) << x << " : "
				     << setw( 9 ) << data[ x ]
				     << endl;
			} // end for
			cout << endl;
		} // end print ( )

		void read ( ) {
			cout << endl;
			for ( int x = 0; x < length; x = x + 1 ) {
				cout << setw( 3 ) << x << " : ";
				cin >> data[ x ]; getchar();
			} // end for
			cout << endl;
		} // end read ( )

		void fprint ( string fileName ) {
			ofstream afile; // output file
			afile.open ( fileName );
			afile << length << endl;
			for ( int x = 0; x < length; x = x + 1 ) {
				afile << data[ x ] << endl;
			} // end for
			afile.close ( );
		} // end fprint ( )

		void fread ( string fileName ) {
			ifstream afile; // input file
			int n = 0;
			afile.open ( fileName );
			afile >> n;
			if ( n <= 0 ) {
				cout << "\nERROR: Invalid length.\n" << endl;
			} else {
				// guardar a quantidade de dados
				length = n;
				// reservar area
				data = new int [ n ];
				// ler dados
				for ( int x = 0; x < length; x = x + 1 ) {
					afile >> data[ x ];
				} // end for
			} // end if
			afile.close ( );
		} // end fread ( )


		const int getLength ( ) {
			return ( length );
		} // end getLength ( )

		void setLength(int value) {
			this->length = value;
		}
		Int_Array* pushBack(int value) {
			int x = this->getLength();
			//this->data = new int[x+1]; não precisa fazer nova alocacao de dados??
			if (data) {
				this->setLength(x + 1);
				this->set(x, value);
			}

			return (this);
		}
		Int_Array* popBack() {
			int newSize = getLength() - 1;
			int copy[newSize];
			for (int i = 0; i < newSize; i++) {
				copy[i] = get(i);
			}
			this->data = new int[newSize];
			for (int i = 0; i < newSize; i++) {
				this->set(i, copy[i]);
			}
			this->setLength(newSize);
			return (this);
		}
	
		Int_Array* pushFront(int value) {
			int copy[getLength()];
			for(int i = 0; i<getLength(); i++){
				copy[i] = get(i);
			}
			this->data = new int[getLength()+1];
			this->setLength(getLength()+1);
			set(0,value);
			for(int i = 0; i<getLength(); i++){
				set(i+1,copy[i]);
			}
			return (this);
		}
	
	Int_Array* popFront(){
		int copy[getLength()];
		for(int i = 0; i<getLength(); i++){
			copy[i] = get(i);
		}
		this->setLength(getLength()-1);
		this->data = new int [getLength()];
		for(int i = 0; i<getLength(); i++){
			set(i,copy[i+1]);
		}
		return(this);
	}
	
	Int_Array* pushMid(int value){
		int copy[getLength()];
		for(int i = 0; i<getLength(); i++){
			copy[i] = get(i);
		}
		this->setLength(getLength()+1);
		this->data = new int [getLength()];
		int meio = getLength()/2;
		for(int i = 0; i<getLength(); i++){
			if(i == meio){
				set(i,value);
			}
			else if(i < meio){
				set(i,copy[i]);
			} else {
				set(i,copy[i-1]);
			}
		}
		return(this);
	}

	Int_Array* popMid(){
		int meio = getLength()/2;
		int copy[getLength()];
		for(int i = 0; i<getLength(); i++){
			copy[i] = get(i);
		}
		this->setLength(getLength()-1);
		this->data = new int [getLength()];
		for(int i = 0; i<getLength(); i++){
			if(i < meio){
				set(i,copy[i]);
			} else{
				set(i,copy[i+1]);
			}
		}
		return(this);
	}
	// condicao: mesmo tamanho de arranjos
	int cmp(Int_Array* other){
		int res = 0;
	//	this->print();
	//	other->print();
		if(other->getLength() == getLength()){
			int x = 0;
			while(x<getLength() && res == 0){
				res = get(x) - other->get(x);
			//	cout << "res :" << res << " 1: "<<get(x)<< " 2: " << other->get(x) << endl;
				x++;
			}
		}
		return(res);
	}
	
	Int_Array* cat(Int_Array* other){
		int size = getLength() + other->getLength();
		int mineSize = getLength();
		int copy[getLength()];
		for(int i = 0; i<getLength(); i++){
			copy[i] = get(i);
		}
		this->setLength(size);
		this->data = new int[size];
		
		for(int i = 0; i<getLength(); i++){
			if(i < mineSize){
				set(i,copy[i]);
			} else {
				set(i,other->get(i-mineSize));
			}
		}
		return(this);
	}
	
	Int_Array* seek(int x){
		Int_Array* apontador = nullptr;
		int i = 0;
		bool achou = false;
		while(i<getLength() && !achou){
			if(get(i) == x){
				achou = true;
				apontador = new Int_Array(1,-1);
				apontador->data[0] = this->data[i];
				apontador->setLength(1);
			}
			i++;
		}
		return(apontador);
	}
	
	Int_Array* sub(int start, int size){
		Int_Array* tmp = nullptr;
		int x = 0;
		int y = 0;
		if(0 <= start && start < getLength() && size > 0){
			y = start;
			tmp = new Int_Array(size,0);
		//	tmp->print();
			while(y<this->getLength() && x<size){
				tmp->set(x,get(y));
				y++;
				x++;
			}
		}
		return(tmp);
	}
	
	Int_Array* merge(Int_Array* other){
		Int_Array* tmp = nullptr;
		if(data && other->data && other){
			int x = 0;
			int y = 0;
			int i = 0;
			tmp = new Int_Array(getLength()+other->getLength(),0);
			while(x<getLength() || y<other->getLength()){
				if(x<getLength()){
					tmp->set(i,get(x));
					i++;
					x++;
				}
				if(y<other->getLength()){
					tmp->set(i,other->get(y));
					i++;
					y++;
				}
			}
		}
		return(tmp);
	}
	
	Int_Array* crescent(){
		Int_Array* tmp = nullptr;
		if(this->data){
			tmp = new Int_Array(getLength(),0);
			// copiar
			for(int y = 0; y<getLength();y++){ 
				tmp->set(y,get(y));
			}
			int holder = 0;
			// ordenar
			for(int x = 1; x<getLength(); x++){
				for(int y = 1; y<getLength();y++){
					if(tmp->get(y-1) > tmp->get(y)){
						holder = tmp->get(y);
						tmp->set(y,tmp->get(y-1));
						tmp->set(y - 1,holder);
					}
				}
			}
			
		}
		return(tmp);
	}
	
	Int_Array* mergeUp(Int_Array* other){
		Int_Array* res = nullptr;
		Int_Array* a1 = nullptr;
		Int_Array* a2 = nullptr;
		if(this->data && other && other->data){
			a1 = this->crescent();
			a1->print();
			a2 = other->crescent();
			a2->print();
			res = a1->merge(a2);
		}
		
		return(res);
	}
};
#endif
